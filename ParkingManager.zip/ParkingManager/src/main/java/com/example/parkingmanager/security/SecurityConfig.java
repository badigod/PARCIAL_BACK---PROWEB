package com.example.parkingmanager.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        
        AuthenticationManagerBuilder auth = http.getSharedObject(AuthenticationManagerBuilder.class);
        auth.inMemoryAuthentication()
            .withUser("admin").password("admin123").roles("ADMIN") // Credenciales Admin
            .and()
            .withUser("user").password("user123").roles("USER");  // Credenciales Usuario

        http
            .authorizeHttpRequests(authorize ->
                authorize
                    .requestMatchers("/admin/**").hasRole("ADMIN")
                    .requestMatchers("/user/**").hasRole("USER")
                    .anyRequest().authenticated()
            )
            .formLogin(formLogin ->
                formLogin
                    .defaultSuccessUrl("/admin/vehicles", true) // Redirigir despues del login
            )
            .logout(logout ->
                logout.permitAll() // Permitir logout a todos
            );

        return http.build(); // Construcción de la cadena de seguridad
    }

	@Bean
    public static NoOpPasswordEncoder passwordEncoder() {
        return (NoOpPasswordEncoder) NoOpPasswordEncoder.getInstance(); // Sin encriptación para desarrollo
    }
}
