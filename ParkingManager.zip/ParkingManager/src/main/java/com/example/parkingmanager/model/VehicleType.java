package com.example.parkingmanager.model;

public enum VehicleType {
	CAR,
    MOTORCYCLE,
    BICYCLE

}
